{
  'info' => {
    'server'         => '',
    'username'       => '',
    'password'       => '',
    'port'           => '0',
    'prognum'        => '0',
    'authentication' => '',
    'enable_debug_logging' => 'No'
  },
  'parameters' => {
    'validation_status' => 'Test Validation Status',
    'submission_id' => ''
  } 
}