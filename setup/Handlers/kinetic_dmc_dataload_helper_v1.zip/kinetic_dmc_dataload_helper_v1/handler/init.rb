require 'rexml/document'
require 'ars_models'
require 'csv'
require 'base64'

class KineticDmcDataloadHelperV1
  # Prepare for execution by pre-loading Ars form definitions, building Hash
  # objects for necessary values, and validating the present state.  This method
  # sets the following instance variables:
  # * @input_document - A REXML::Document object that represents the input Xml.
  # * @debug_logging_enabled - A Boolean value indicating whether logging should
  #   be enabled or disabled.
  # * @parameters - A Hash of parameter names to parameter values.
  # * @field_values - A Hash of KS_SRV_CustomerSurvey_base database field names
  #   to the values that will be set on the submission record.
  #
  # This is a required method that is automatically called by the Kinetic Task
  # Engine.
  #
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml 
  #   handler template.
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Initialize the handler and pre-load form definitions using the credentials
    # supplied by the task info items.
    preinitialize_on_first_load(
      @input_document,
      ['KS_SRV_Helper','KS_BRG_AttributeMapping','KS_SRV_SurveyQuestion','KS_SRV_QuestionAnswerJoin','KS_ACC_Attachment','KS_BRG_QualificationMapping']
    )

    # Determine if debug logging is enabled.
    @debug_logging_enabled = get_info_value(@input_document, 'enable_debug_logging') == 'Yes'
    puts("Logging enabled.") if @debug_logging_enabled

    # Store parameters in the node.xml in a hash attribute named @parameters.
    @parameters = {}
    REXML::XPath.match(@input_document, '/handler/parameters/parameter').each do |node|
      @parameters[node.attribute('name').value] = node.text
    end
    puts(format_hash("Handler Parameters:", @parameters)) if @debug_logging_enabled

    # Retrieve the list of field values that will be written to the approval record
    @field_values = {}
    REXML::XPath.match(@input_document, '/handler/fields/field').each do |node|
      @field_values[node.attribute('name').value] = node.text
    end
    puts(format_hash("Field Values:", @field_values)) if @debug_logging_enabled
  end
  # Creates a record in the KS_SRV_Helper form
  #
  # This is a required method that is automatically called by the Kinetic Task
  # Engine.
  #
  # ==== Returns
  # An Xml formatted String representing the return variable results.
  def execute()
    # Initialize Results variables
	status=""
	error_code=""
	results_message=""
	
	# If header_row doesn't evaluate to "Yes" or "No", exit.
	if @parameters['header_row'].upcase != "YES" && @parameters['header_row'].upcase != "NO"
		raise (%|The 'Header Row' input element must evaluate to 'Yes' or 'No'.|)
	end
	
	#Initialize field variables
	data_type_helper_fields=@parameters['bridge_attributes'].split('||')
	returned_bridge_attribute_hash={}
	bridge_attributes_used=[]
	
	# Retrieve the CSV file
    csvfile = get_attachment(@parameters['customer_survey_instance_id'],@parameters['csv_file'], @parameters['survey_template_instance_id'])
	
	# Retrieve bridge attributes from KS_BRG_AttributeMapping for the identified bridge model
    bridge_attributes = @@remedy_forms['KS_BRG_AttributeMapping'].find_entries(
      :all,
      :conditions => [%|'Status' = "Active" AND 'model_name' = "#{@parameters['bridge_model']}"|],
      :fields => ['attribute_name','field_mapping']
    )

    if bridge_attributes.nil? || bridge_attributes.empty?
	  status="Error"
	  error_code="001"
	  results_message="This data type '#{@parameters['data_type']}' uses the bridge model '#{@parameters['bridge_model']}', which could not be found or contains no field mappings for the data bridge."
    end
	
	if status!="Error"
		# Loop through to find the returned attributes and strip the wrappers
		bridge_attributes.each {|record|
			n = record['attribute_name']
			m = record['field_mapping']
			
			# Strip off the wrappers around the field name.  Expected format:  <%=field["Field Name Here"]%>
			returned_bridge_attribute_hash[n]=m[10,m.length-14]
			puts "Bridge Attribute: #{returned_bridge_attribute_hash[n]}" if @debug_logging_enabled
		}
		
		# Loop through each of the data helper fields and extract the correlating field names from the returned_bridge_attribute_hash.
		# The order must match that of the data_type_helper_fields, because that is how the data is expect to be input by the user in the CSV file.
		data_type_helper_fields.each {|record|
			if returned_bridge_attribute_hash.has_key?(record)
				bridge_attributes_used.push(returned_bridge_attribute_hash[record])
			else
				status="Error"
				error_code="002"
				results_message="Each column identified in the data type definition '#{@parameters['data_type']}' must have a matching bridge model attribute.  '#{record}' did not have a matching attribute value in the data model."
			end
		}
		
		if status!="Error"
			if @parameters['replace_existing_records'].upcase=="YES"
				
				# Extract the attribute names and values from the input parameter string, @parameters['bridge_parameters']
				# Expected format:  Parameter Field Name 1::"Value"||Parameter Field Name 2::"Value"
				bridge_parameters_array = @parameters['bridge_parameters'].split("||")
				bridge_parameters_hash = {}
				bridge_parameters_array.each {|x|
					# replace any double quotes
					bridge_parameters_hash[x.split("::")[0]]=x.split("::")[1].gsub(/""/,'"')
				}
				puts "Bridge Parameter Hash: #{bridge_parameters_hash}" if @debug_logging_enabled
				puts "Bridge Parameter Hash (inspect): #{bridge_parameters_hash.inspect}" if @debug_logging_enabled
				
				# retrieve the bridge qualifications
				bridge_qualification_entry = @@remedy_forms['KS_BRG_QualificationMapping'].find_entries(
					:single,
					:conditions => [%|'Status' = "Active" AND 'model_name' = "#{@parameters['bridge_model']}" AND 'qualification_name' = "#{@parameters['bridge_qualification']}"|],
					:fields => ['query']
				)
				
				# if bridge qualification is not null, build up the Remedy qualifications.  Parameters returned as part of the string
				# are expected in this format <%=parameter["Field Name"]%>
				if !bridge_qualification_entry.nil?
					puts "Bridge query: #{bridge_qualification_entry['query']}" if @debug_logging_enabled
					bridge_qual_param_array=bridge_qualification_entry['query'].scan(/<%=parameter\[".*?"]%>/i)
					puts "Bridge query parameter array (inspect): #{bridge_qual_param_array.inspect}" if @debug_logging_enabled
					bridge_qual_param_hash={}
					bridge_qual_param_array.each {|value|
						bridge_qual_param_hash[value]=bridge_parameters_hash[value[14,value.length-18]]
					}
					puts ("Bridge Qual Param Hash: #{bridge_qual_param_hash}") if @debug_logging_enabled
					puts ("Bridge Qual Param Hash (inspect): #{bridge_qual_param_hash.inspect}") if @debug_logging_enabled

				else
					raise("Bridge Qualification #{@parameters['bridge_qualification']} for the bridge model #{@parameters['bridge_model']} could not be found.")
				
				end
				
				# Retrieve all data type values.  Must replace the query parameters (if any) with actual values
				qual = bridge_qualification_entry['query']
				puts "Qual (starting): #{bridge_qualification_entry['query']}" if @debug_logging_enabled
				bridge_qual_param_hash.each {|key,value|
					qual = qual.gsub(key,value)
				}
				puts "Qual (ending): #{qual}" if @debug_logging_enabled
				
				existing_data_type_entries = @@remedy_forms['KS_SRV_Helper'].find_entries(
					:all,
					:conditions => [qual],
					:fields => ['Request ID']
				)
				
				# execute a call to update all matching values setting the status to 'Delete' and the adding a short description of "Marked Deleted - DMC Upload Process - Date/Time"
				if existing_data_type_entries.length>0
				    current_time = Time.new
					current_time_format = current_time.strftime("%b %d, %Y at %I:%M%p (Server Time)")
					existing_data_type_entries.each {|record|
						record.update_attributes!({
							"Status" => "Delete",
							"Short Description" => "Marked Deleted (by DMC Upload Process): #{current_time_format}"
						})
					}
				end
				results_message="#{existing_data_type_entries.length} existing records marked deleted. "
			end
		end
		
		#set colunmn_count variable
		column_count=data_type_helper_fields.length
		
		if status!="Error"
			# csvfile is an ARSmodels attachment type.  The base64_content contains the actual file content.
			
			records=Base64.decode64(csvfile.base64_content).split(/\r?\n/)
			
			if records.length>0
				#if header_row="Yes", ignore the first row
				if @parameters['header_row'].upcase=='YES'
				   records.shift
				end
			end
			
			puts "Bridge Attributes Used: #{bridge_attributes_used.inspect}" if @debug_logging_enabled
			
			rowcount=0
			
			records.each do |record|
				inputArray = CSV.parse(record)
				
				# Set variables
				rowcount += 1
				column_num = 0
				@field_values = {}
				
				
				if inputArray[0].length < column_count
				   raise("Too few data columns for record #{rowcount}.\nData: #{inputArray[0].inspect}")
				end
				
				while column_num < column_count
					# Add field_values
					@field_values[bridge_attributes_used[column_num]]=inputArray[0][column_num]

					# Increment column number
					column_num += 1
				end
				
				puts("Working on row: #{@field_values.inspect}") if @debug_logging_enabled
				#create entry

				# Create the KS_SRV_Helper record using the @field_values hash
				# that was built up.  Pass 'Associations ID' to the fields
				# argument because these fields will be used in the results xml.
				entry = @@remedy_forms['KS_SRV_Helper'].create_entry!(
				:field_values => @field_values,
				:fields       => []
				)
			end
			
			status="Success"
			results_message += "#{records.length} records created."
		end
	end



    # Build the results xml that will be returned by this handler.
    results = <<-RESULTS
    <results>
      <result name="Status">#{status}</result>
	  <result name="Error Code">#{error_code}</result>
	  <result name="Result Message">#{results_message}</result>
    </results>
    RESULTS
    puts("Results: \n#{results}") if @debug_logging_enabled

    # Return the results String
    return results
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # Preinitialize expensive operations that are not task node dependent (IE
  # don't change based on the input parameters passed via xml to the #initialize
  # method).  This will very frequently utilize task info items to do things
  # such as pre-load a Remedy form or generate a Remedy proxy user.
  def preinitialize_on_first_load(input_document, form_names)
    # Unless this method has already been called...
    unless self.class.class_variable_defined?('@@preinitialized')
      # Initialize a remedy context (login) account to execute the Remedy queries.
      @@remedy_context = ArsModels::Context.new(
        :server         => get_info_value(input_document, 'server'),
        :username       => get_info_value(input_document, 'username'),
        :password       => get_info_value(input_document, 'password'),
        :port           => get_info_value(input_document, 'port'),
        :prognum        => get_info_value(input_document, 'prognum'),
        :authentication => get_info_value(input_document, 'authentication')
      )
      # Initialize the remedy forms that will be used by this handler.
      @@remedy_forms = form_names.inject({}) do |hash, form_name|
        hash.merge!(form_name => ArsModels::Form.find(form_name, :context => @@remedy_context))
      end
      # Store that we are preinitialized so that this method is not called twice.
      @@preinitialized = true
    end
  end

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}

  # Builds a string that is formatted specifically for the Kinetic Task log file
  # by concatenating the provided header String with each of the provided hash
  # name/value pairs.  The String format looks like:
  #   HEADER
  #       KEY1: VAL1
  #       KEY2: VAL2
  # For example, given:
  #   field_values = {'Field 1' => "Value 1", 'Field 2' => "Value 2"}
  #   format_hash("Field Values:", field_values)
  # would produce:
  #   Field Values:
  #       Field 1: Value 1
  #       Field 2: Value 2
  def format_hash(header, hash)
    # Staring with the "header" parameter string, concatenate each of the
    # parameter name/value pairs with a prefix intended to better display the
    # results within the Kinetic Task log.
    hash.inject(header) do |result, (key, value)|
      result << "\n    #{key}: #{value}"
    end
  end

  # This is a sample helper method that illustrates one method for retrieving
  # values from the input document.  As long as your node.xml document follows
  # a consistent format, these type of methods can be copied and reused between
  # handlers.
  def get_info_value(document, name)
    # Retrieve the XML node representing the desird info value
    info_element = REXML::XPath.first(document, "/handler/infos/info[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    info_element.nil? ? nil : info_element.text
  end
  
  def get_attachment(customer_survey_instance_id, attachment_question_menu_label, survey_template_instance_id)
    survey_question_entry = @@remedy_forms['KS_SRV_SurveyQuestion'].find_entries(
      :single,
      :conditions => [%|'Editor Label' = "#{attachment_question_menu_label}" AND 'SurveyInstanceID' = "#{survey_template_instance_id}"|],
      :fields     => ['instanceId']
    )
    # A question record on KS_SRV_SurveyQuestion could not be found with the given
    # attachment_question_menu_label and survey_template_instance_id parameters.
    if survey_question_entry.nil?
      raise("No question was found with given label #{attachment_question_menu_label}")
    end
    
    question_answer_entry = @@remedy_forms['KS_SRV_QuestionAnswerJoin'].find_entries(
      :single,
      :conditions => [%|'QuestioninstanceId' = "#{survey_question_entry['instanceId']}" AND 'CustomerSurveyInstanceID' = "#{customer_survey_instance_id}"|],
      :fields     => ['answerinstanceId']
    )
    # The question does not have a related KS_SRV_QuestionAnswerJoin record for
    # the current submission.
    return nil if question_answer_entry.nil?

    attachment_entry = @@remedy_forms['KS_ACC_Attachment'].find_entries(
      :single,
      :conditions => [%|'FormID' = "#{question_answer_entry['answerinstanceId']}"|],
      :fields     => ['At_AttachmentOne']
    )
    # The answer does not have a related KS_ACC_Attachment record.
    return nil if attachment_entry.nil?

    # Return the 'At_AttachmentOne' field from the KS_ACC_Attachment record.
    attachment_entry['At_AttachmentOne']
  end
  
end
