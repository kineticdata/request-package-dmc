{
  'info' => {
    'server'         => 'emu.kineticdata.com',
    'username'       => 'Demo',
    'password'       => '',
    'port'           => '3000',
    'prognum'        => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'data_type' => 'Database Roles',
    'bridge_model' => 'Data Management Console - Helper Data',
	'bridge_qualification' => 'Index 1 | Index 2 | Index 3 (exact match/null)',
	'bridge_parameters' => 'Index Field 1::""Service Item Menu""||Index Field 2::""Shared Menu""||Index Field 3::""DB Roles""',
	'bridge_attributes' => 'Character Field 1||Character Field 2||Index Field 1||Index Field 2||Index Field 3||Status',
	'header_row' => 'Yes',
	'csv_file' => 'CSV File',
	'replace_existing_records' => 'No'
  },
  'base' => {
	'CustomerSurveyInstanceId' => 'AG00505696001CcrSeUgF5z3ZQPpNA',
	'surveyTemplateInstanceID' => 'KS00505696001CUdmcUghaK3Xg9OM6'
  }
}